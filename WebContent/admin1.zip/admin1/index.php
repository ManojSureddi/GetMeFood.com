<?php
 include('../include/config.php');
if(isset($_GET['page'])){
$page=$_GET['page'];
}
else{
$page=md5('home');
}
include('header.php');

if($page==md5('home')){
include('home.php');
}
else if($page==md5('employee')){
include('employee.php');
}
else if($page==md5('restaurant')){
include('restaurant.php');
}
else if($page==md5('menu')){
include('menu.php');
}
else if($page==md5('employeestatuschange')){
include('changeempstatus.php');
}
else if($page==md5('vieworders')){
include('../orderdbview.php');
}
else if($page==md5('viewdeliverboystatus')){
include('../deliveryboystatus.php');
}
else{
include('404.php');
}
?>