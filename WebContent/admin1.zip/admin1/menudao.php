<?php
  session_start();
include('../include/config.php');

 $restid=mysql_real_escape_string($_POST['restaurantid']);
$itemtype=mysql_real_escape_string($_POST['itemtype']);
$itemname=mysql_real_escape_string($_POST['itemname']);
$itemprice=mysql_real_escape_string($_POST['itemprice']);
$desc=mysql_real_escape_string($_POST['description']);
$status=mysql_real_escape_string($_POST['status']);
 $re=mysqli_query($con,"SELECT * FROM `restaurant_menu` WHERE `Restaurant_Id`= '".$restid."'");
 $k=mysqli_num_rows($re);
 $res=mysqli_query($con,"INSERT INTO `restaurant_menu`(`Restaurant_Id`, `Item_Type`, `Item_Code`, `Name`, `Price`, `Description`, `Item_State`) VALUES ('".$restid."','".$itemtype."','R".$restid."I".($k+1)."','".$itemname."','".$itemprice."','".$desc."','".$status."')");
 if(mysqli_affected_rows($con))
{
	$_SESSION['status']=true;
}
 else
 {
 $_SESSION['status']=false;
 }
 
header("location:index.php?page=".md5('menu'));
?>