<?php
  session_start();
include('../include/config.php');
 $re=mysqli_query($con,"SELECT * FROM `restaurants`");
 $k=mysqli_num_rows($re);
 $name=mysql_real_escape_string($_POST['empname']);
$emprole=mysql_real_escape_string($_POST['emprole']);
$phone=mysql_real_escape_string($_POST['phone']);
$passwd=mysql_real_escape_string($_POST['passwd']);
$status=mysql_real_escape_string($_POST['status']);
$empareacode=mysql_real_escape_string($_POST['empareacode']);

mysqli_query($con,"INSERT INTO `employee`(`Emp_ID`, `Emp_Name`, `Emp_Role`, `Phone`, `Password`, `Status`, `Area_Code`) VALUES (".($k+1).",'".$name."','".$emprole."','".$phone."','".$passwd."','".$status."','".$empareacode."')");
if(mysqli_affected_rows($con))
{
	$_SESSION['status']=true;
}
 else
 {
 $_SESSION['status']=false;
 }
 
header("location:index.php?page=".md5('employee'));
?>