<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<img src="img/404.jpg"  style="background-position:center; background-size:cover; width:70%;">
</body>
</html>