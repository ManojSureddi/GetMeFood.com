<div id="rightbox">
<div class="container">
<?php
session_start();

	  if(isset($_SESSION['status'])){
	  $a=$_SESSION['status'];
	  if($a)
	  {
	   echo '<span class="alert alert-success" > Registration Succesfull</span>';
	  }
	  else
	  {
	   echo '<span class="alert alert-danger" >Regitration Unsuccesfull</span>';
	  }
	  unset($_SESSION['status']);
	  }
?>
<h4>Restaurant Registration</h4>
<form action="restaurantdao.php" method="post">
<table>
<tr><td>Name:</td><td><input type="text" name="restname" required></td></tr>
<tr><td>City Code:</td><td><input type="text" name="citycode" required></td></tr>
<tr><td>Area Code:</td><td><input type="text" name="areacode" required></td></tr>
<tr><td>Contact Person Name:</td><td><input type="text" name="contactname" required></td></tr>
<tr><td>Phone1:</td><td><input type="text" name="phone1" maxlength="10" required></td></tr>
<tr><td>Phone2:</td><td><input type="text" name="phone2" maxlength="10"  required></td></tr>
<tr><td>Address:</td><td><textarea name="address" rows="5" cols="10" required></textarea></td></tr>
<tr><td>Status</td><td><select name="status">
<option value="SERVED">Served</option>
<option value="UNSERVED">Unserved</option>
</select></td></tr>
<tr><td>Reason:</td><td><input type="text" name="reason"  required></td></tr>
<tr><td>Time Slot_1 Start:</td><td><input type="text" name="tstart1" required></td></tr>
<tr><td>Time Slot_1 end:</td><td><input type="text" name="tend1" required></td></tr>
<tr><td>Time Slot_2 Start:</td><td><input type="text" name="tstart2" required></td></tr>
<tr><td>Time Slot_2 end:</td><td><input type="text" name="tend2" required></td></tr>
<tr><td></td><td><input type="submit" name="submit" class="submitbut"  value="Register Restaurant"/>
</td></tr>
</table>
</form>
</div>
</div>
</section>
</body>
</html>