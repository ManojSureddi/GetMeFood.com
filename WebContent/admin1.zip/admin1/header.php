<html>
<head>
<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/main.css"/>
<style>
select{
height:39px;
  width: 306px;
}
body
{
	background:#FFF;
}
 #three th
{
	background:#00a478 !important;
	color:#FFF;
	padding:10px 10px 10px 10px;
	
}
 #three table
{
	margin:auto;
	margin-top:60px;
	border:1px solid #00a478;

}
 #three td
{
		padding:10px 10px 10px 10px;
}
#three tbody > tr:nth-child(odd) > td {
  background-color: #f9f9f9;
  padding:10px 10px 10px 10px;
}
#three tbody > tr:nth-child(even) > td{
  background-color: #CCCCCC;
  padding:10px 10px 10px 10px;
}
</style>
</head>
<body>
<section id="two">
<div id="sidebox">
<ul>
<li><a href="index.php?page=<?php echo md5('home')?>">Home</a></li>
<li><a href="index.php?page=<?php echo md5('employee')?>">Add Employee</a></li>
<li><a href="index.php?page=<?php echo md5('restaurant')?>">Add Restaurant</a></li>
<li><a href="index.php?page=<?php echo md5('menu')?>">Add Menu Items</a></li>
<li><a href="index.php?page=<?php echo md5('employeestatuschange')?>">Change Status</a></li>
<li><a href="index.php?page=<?php echo md5('vieworders')?>">View Orders</a></li>
<li><a href="index.php?page=<?php echo md5('viewdeliverboystatus')?>">Delivery Boy Status</a></li>
<li><a href="index.php?page=<?php echo md5('employeeview')?>">Employee View</a></li>
<li><a href="index.php?page=<?php echo md5('searchrestarant')?>">Search Restaurant</a></li>


</ul>
</div>
