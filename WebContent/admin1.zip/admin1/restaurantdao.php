<?php
  session_start();
include('../include/config.php');
 $re=mysqli_query($con,"SELECT * FROM `restaurants`");
 $k=mysqli_num_rows($re);
 
$name=mysql_real_escape_string($_POST['restname']);
$citycode=mysql_real_escape_string($_POST['citycode']);
$areacode=mysql_real_escape_string($_POST['areacode']);
$contactname=mysql_real_escape_string($_POST['contactname']);
$phn1=mysql_real_escape_string($_POST['phone1']);
$phn2=mysql_real_escape_string($_POST['phone2']);
$address=mysql_real_escape_string($_POST['address']);
$status=mysql_real_escape_string($_POST['status']);
$reason=mysql_real_escape_string($_POST['reason']);
$tstart1=mysql_real_escape_string($_POST['tstart1']);
$tend1=mysql_real_escape_string($_POST['tend1']);
$tstart2=mysql_real_escape_string($_POST['tstart2']);
$tend2=mysql_real_escape_string($_POST['tend2']);

$res=mysqli_query($con,"SELECT * FROM `restaurants` where Phone1='".$phn1."' or Address='".$address."'");
if(mysqli_affected_rows($con)){
 mysqli_query($con,"INSERT INTO `restaurants`(`Restaurant_Id`, `Name`, `City_Code`, `Area_Code`, `Contact_Person`, `Phone1`, `Phone2`, `Address`, `Status`, `Reason`, `Time_Slot_1_ST`, `Time_Slot_1_ET`, `Time_Slot_2_ST`, `Time_Slot_2_ET`)
 VALUES (".($k+1).",'".$name."','".$citycode."','".$areacode."','".$contactname."','".$phn1."','".$phn2."','".$address."','".$status."','".$reason."','".$tstart1."','".$tend1."','".$tstart2."','".$tend2."')");
if(mysqli_affected_rows($con))
{
	$_SESSION['status']=true;
}
 else
 {
 $_SESSION['status']=false;
 }
 }else{
  $_SESSION['status']=false;
 }
header("location:index.php?page=".md5('restaurant'));
?>